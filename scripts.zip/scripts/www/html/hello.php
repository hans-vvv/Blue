<?php echo '<p>Hello PHP World</p>'; ?> 
